// Starter code for ECE 455

// Written by Bernie Roehl, December 2021

void Initialize(void);
void SetLED(int n);
void ClearLED(int n);
unsigned int ReadJoystick(void);
unsigned int ReadPotentiometer(void);
int ReadPushbutton(void);

